<header class=" scroll_top  fixed scrolled_not_transparent with_border page_header">
    <div class="header_inner clearfix">

        <div class="header_top_bottom_holder">
            <div class="header_bottom clearfix" style=' background-color:rgba(0, 0, 0, 0.6);'>
                <div class="header_inner_left">
                    <div class="mobile_menu_button">
                        <span>
                            <i class="qode_icon_font_awesome fa fa-bars "></i> </span>
                    </div>
                    <div class="logo_wrapper">
                        <div class="q_logo">
                            <a itemprop="url" href="#">
                                <!-- <img itemprop="image" class="normal" src="http://www.hallelectrical.ca/wp-content/uploads/2018/09/Hall-Electrical-Logo-vancouver-desktop.png" alt="Logo" /> -->
                                <!-- Images link Below -- Auth Swapnil -->
                                <img itemprop="image" class="normal" src="Assets/images/logo2.png" alt="Logo" />
                                
                                <img itemprop="image" class="light" src="http://demo.qodeinteractive.com/bridge5/wp-content/uploads/2014/05/logo_retina.png" alt="Logo" />
                                <img itemprop="image" class="dark" src="http://demo.qodeinteractive.com/bridge5/wp-content/uploads/2014/05/logo_retina.png" alt="Logo" />
                                <img itemprop="image" class="sticky" src="http://demo.qodeinteractive.com/bridge5/wp-content/uploads/2014/05/logo_retina.png" alt="Logo" />
                                <img itemprop="image" class="mobile" src="http://www.hallelectrical.ca/wp-content/uploads/2018/09/Hall-Electrical-Logo-vancouver-mobile.png" alt="Logo" />
                            </a>
                        </div>
                    </div>
                </div>
                <div class="header_inner_right">
                    <div class="side_menu_button_wrapper right">
                        <div class="header_bottom_right_widget_holder">
                            <div class="header_bottom_widget widget_text">
                                <div class="textwidget"><span class='q_social_icon_holder normal_social' data-color=#ffffff data-hover-color=#009344><a itemprop='url' href='https://www.facebook.com/hallelectricalvancouver/' target='_blank' rel="noopener noreferrer"><i class="qode_icon_font_awesome fa fa-facebook fa-lg simple_social" style="color: #ffffff;"></i></a></span>

                                    <span class='q_social_icon_holder normal_social' data-color=#ffffff data-hover-color=#009344><a itemprop='url' href='https://www.instagram.com/hallelectrical/' target='_blank' rel="noopener noreferrer"><i class="qode_icon_font_awesome fa fa-instagram fa-lg simple_social" style="color: #ffffff;"></i></a></span>

                                    <a itemprop="url" href="http://www.hallelectrical.ca/contact-us/" target="_self" data-hover-background-color="#009344" data-hover-border-color="#009344" data-hover-color="#000" class="qbutton  medium default" style="color: #ffffff; border-color: #ffffff; background-color: transparent;" rel="noopener noreferrer">REQUEST SERVICE</a>
                                </div>
                            </div><span class='q_social_icon_holder normal_social'><a itemprop='url' href='https://www.instagram.com/hallelectrical/' target='_blank'><i class="qode_icon_font_awesome fa   simple_social" style=""></i></a></span>
                        </div>
                        <div class="side_menu_button">

                        </div>
                    </div>
                </div>


                <nav class="main_menu drop_down right">
                    <ul id="menu-primary-menu" class="">
                        <li id="nav-menu-item-16273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-15694 current_page_item active narrow"><a href="index.php" class=" current "><i class="menu_icon blank fa"></i><span>Home</span><span class="plus"></span></a></li>
                        <li id="nav-menu-item-6" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="about.php" class=""><i class="menu_icon blank fa"></i><span>About</span><span class="plus"></span></a></li>
                        <li id="nav-menu-item-16271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has_sub narrow"><a href="Service.php" class=""><i class="menu_icon blank fa"></i><span>Services</span><span class="plus"></span></a>
                            <div class="second">
                                <div class="inner">
                                    <ul>
                                        <li id="nav-menu-item-17804" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="EVchar.php" class=""><i class="menu_icon blank fa"></i><span>EV Chargers</span><span class="plus"></span></a></li>
                                        <li id="nav-menu-item-17805" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="Resid.php" class=""><i class="menu_icon blank fa"></i><span>Residential</span><span class="plus"></span></a></li>
                                        <li id="nav-menu-item-17806" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="commer.php" class=""><i class="menu_icon blank fa"></i><span>Commercial</span><span class="plus"></span></a></li>
                                        <li id="nav-menu-item-17511" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="sam.php" class=""><i class="menu_icon blank fa"></i><span>Service &#038; Maintenance</span><span class="plus"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li id="nav-menu-item-16272" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="portfolio.php" class=""><i class="menu_icon blank fa"></i><span>Portfolio</span><span class="plus"></span></a></li>
                        <li id="nav-menu-item-17755" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="career.php" class=""><i class="menu_icon blank fa"></i><span>Careers</span><span class="plus"></span></a></li>
                        <li id="nav-menu-item-16736" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="#" class=""><i class="menu_icon blank fa"></i><span>Contact Us</span><span class="plus"></span></a></li>
                    </ul>
                </nav>
                <nav class="mobile_menu">
                    <ul id="menu-primary-menu-1" class="">
                        <li id="mobile-menu-item-16273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-15694 current_page_item active"><a href="http://www.hallelectrical.ca/" class=" current "><span>Home</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                        <li id="mobile-menu-item-6" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="about.php" class=""><span>About</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                        <li id="mobile-menu-item-16271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has_sub"><a href="Service.php" class=""><span>Services</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span>
                            <ul class="sub_menu">
                                <li id="mobile-menu-item-17804" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="EVchar.php" class=""><span>EV Chargers</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                                <li id="mobile-menu-item-17805" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="Resid.php" class=""><span>Residential</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                                <li id="mobile-menu-item-17806" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="commer.php" class=""><span>Commercial</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                                <li id="mobile-menu-item-17511" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="sam.php" class=""><span>Service &#038; Maintenance</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                            </ul>
                        </li>
                        <li id="mobile-menu-item-16272" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="portfolio.php" class=""><span>Portfolio</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                        <li id="mobile-menu-item-17755" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="career.php" class=""><span>Careers</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                        <li id="mobile-menu-item-16736" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="#" class=""><span>Contact Us</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

</header>