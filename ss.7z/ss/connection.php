<?php 


$servername = "localhost";

// User Name Specified Below
$username = "Swapnil";

$password = "Swap@9474";

$db = "SSE";

$con = mysqli_connect($servername, $username, $password, $db) or die("Error Connection Database");



?>
<!-- Auth Swapnil :: PHP Version : 7.4.3 -->