<footer class="uncover">
                <div class="footer_inner clearfix">
                    <div class="footer_top_holder">
                        <div class="footer_top">
                            <div class="container">
                                <div class="container_inner">
                                    <div class="four_columns clearfix">
                                        <div class="column1 footer_col1">
                                            <div class="column_inner">
                                                <div id="text-3" class="widget widget_text">
                                                    <div class="textwidget">
                                                        <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 15px; padding-top: 48px;">Hall Electrical Ltd.</h3>
                                                        <p><img src="Assets/images/logo2.png" alt="" width="80" height="80" /></p>
                                                        <ul style="width: 300px;">
                                                            <li style="color: #c7c7c7; font-size: 1em; font-weight: 400; padding-top: 10px; padding-bottom: 5px;">PHONE: <a style="color: #c7c7c7; font-size: 1em; font-weight: 400;" href="tel:16048360181">604-836-0181</a></li>
                                                            <li style="color: #c7c7c7; font-size: 1em; font-weight: 400; padding-bottom: 5px;">EMAIL: <a style="color: #c7c7c7; font-size: 1em; font-weight: 400;" href="mailto:info@hallelectrical.ca">info@hallelectrical.ca</a></li>
                                                            <li style="color: #c7c7c7; font-size: 1em; font-weight: 400; padding-bottom: 5px;">ADDRESS: 120-2055 Commercial Drive</li>
                                                            <li style="color: #c7c7c7; font-size: 1em; font-weight: 400; padding-bottom: 5px;"> Vancouver, BC, V5N 0C7</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column2 footer_col2">
                                            <div class="column_inner">
                                                <div id="text-17" class="widget widget_text">
                                                    <div class="textwidget">
                                                        <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 40px; padding-top: 30px;">Discover</h3>
                                                        <div>
                                                            <ul class="footer-ul-r2" style="list-style-type: disc;">
                                                                <li style="padding-bottom: 10px;"><a style="color: #c7c7c7; font-size: 1em; font-weight: 400; text-decoration: underline;" href="Resid.php">Residential</a></li>
                                                                <p>
                                                                    <!-- 

<li style="padding-bottom: 10px;"><a style="color: #c7c7c7; font-size: 1em; font-weight: 400; text-decoration: underline;" href="http://www.hallelectrical.ca/solar-panel-installation/">Solar Panel Installation</a></li>

 -->
                                                                </p>
                                                                <li style="padding-bottom: 10px;"><a style="color: #c7c7c7; font-size: 1em; font-weight: 400; text-decoration: underline;" href="EVchar.php">EV Car Charger Installation</a></li>
                                                                <li style="padding-bottom: 10px;"><a style="color: #c7c7c7; font-size: 1em; font-weight: 400; text-decoration: underline;" href="sam.php">Electrical Panel Upgrades &amp; Services Upgrades</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column3 footer_col3">
                                            <div class="column_inner">
                                                <div id="text-4" class="widget widget_text">
                                                    <div class="textwidget">
                                                        <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 15px; padding-top: 30px;"><a style="color: #c7c7c7!important; font-size: 20px;text-decoration: underline;" href="http://www.hallelectrical.ca/contact-us">Get A Quote</a></h3>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column3 footer_col3">
                                            <div class="column_inner">
                                                <div id="text-4" class="widget widget_text">
                                                    <div class="textwidget">
                                                        <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 15px; padding-top: 30px;"><a style="color: #c7c7c7!important; font-size: 20px;text-decoration: underline;" href="http://www.hallelectrical.ca/contact-us">Get In Touch</a></h3>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                       <!-- <div class="column4 footer_col4">
                                            <div class="column_inner">
                                                <div id="text-5" class="widget widget_text">
                                                    <div class="textwidget">
                                                      <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 15px; padding-top: 30px; text-decoration: underline;">Read Our Reviews</h3>



                                                        <img src="/wp-content/uploads/2019/09/White-Star.png" alt="" height="" width="20" style="padding-right:3px;padding-bottom:5px;" />

                                                        <img src="/wp-content/uploads/2019/09/White-Star.png" alt="" height="" width="20" style="padding-right:3px;padding-bottom:5px;" />

                                                        <img src="/wp-content/uploads/2019/09/White-Star.png" alt="" height="" width="20" style="padding-right:3px;padding-bottom:5px;" />

                                                        <img src="/wp-content/uploads/2019/09/White-Star.png" alt="" height="" width="20" style="padding-right:3px;padding-bottom:5px;" />

                                                        <img src="/wp-content/uploads/2019/09/White-Star.png" alt="" height="" width="20" style="padding-bottom:5px;" />

                                                        <br>
                                                        <a target="_blank" href="https://goo.gl/Wxc4K4" rel="noopener noreferrer"><img src="/wp-content/uploads/2019/09/Google-Logo-White.png" alt="" height="" width="100" style="padding-right:15px;" /></a>

                                                        <a target="_blank" href="https://www.facebook.com/hallelectricalvancouver/reviews/" rel="noopener noreferrer"><img src="/wp-content/uploads/2019/09/FACEBOOK-VECTOR4.png" alt="" height="" width="120" style="padding-right:15px;" /></a>

                                                        <a target="_blank" href="https://www.yelp.ca/biz/hall-electrical-vancouver" rel="noopener noreferrer"><img src="/wp-content/uploads/2019/09/Yelp_trademark_MONO.png" alt="" height="" width="80" /></a>

                                                        <h3 style="color: #c7c7c7; font-size: 1.5em; padding-bottom: 15px; padding-top: 10px;text-decoration: underline;">Connect With Us</h3>

                                                        <a target="_blank" href="https://www.facebook.com/hallelectricalvancouver/" rel="noopener noreferrer"><img src="/wp-content/uploads/2019/09/Flat-Icons-IG-Facebook1.png" alt="" height="" width="45" style="padding-right:10px;" /></a>

                                                        <a target="_blank" href="https://www.instagram.com/hallelectrical/" rel="noopener noreferrer"><img src="/wp-content/uploads/2019/09/instagram-VECTOR.png" alt="" height="" width="45" /></a>



                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer_bottom_holder">
                        <div class="footer_bottom">
                            <div class="textwidget">
                                <p>Copyright © <script type="text/javascript">
                                        document.write(new Date().getFullYear());
                                    </script> Shiv Shakti Electricals Ltd. |Developed By Swapnil - Miracle Developers Community | <a style="color: #42795f;" href="#" target="_blank" rel="noopener noreferrer">Sitemap</a><br />
                                    <!-- <a style="color: #42795f;" href="https://www.roiwebmarketing.com" target="_blank" rel="noopener noreferrer">Vancouver Internet Marketing</a> by ROI Web Marketing -->
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>